USB Redirector version 5.4
--------------------------

OVERVIEW
--------

THE BEST SOLUTION  FOR SHARING AND ACCESSING   USB DEVICES!	

USB Redirector software allows to access remote USB devices 
via  local  network  or Internet. And from now you can work 
with this  USB device as if  it is plugged directly to your 
computer. Being at home you can use your USB device that is 
physically located in your office and vice versa.


FEATURES
--------

-  USB  Redirector  supports the connection between Windows
   32/64 bit and Linux platforms!

-  USB  Redirector  allows connecting  USB devices that are 
   occupied  by  other  clients  but  not  used  during the 
   certain time!

-  CallBack connection  feature, allowing to connect shared 
   USB devices that are placed over NAT in a local network!

-  USB  Redirector  is the only one of its kind because USB 
   Server  and  USB Client  are  combined into one software 
   product.

-  USB Redirector shares high-speed USB devices(web cameras 
   audio  USB  devices)  over  network.  It supports a wide 
   range of USB devices.

-  USB Redirector  does not require to install USB device's 
   driver software on the PC to share it.

-  Black List feature. A Remote computer that you placed on 
   the Black List can not connect to your computer as  long 
   as you need it!

-  Auto-connecting  of  remote  USB devices as soon as they 
   become available for connection

-  Remote control features.

-  Auto-replacing of network connection if it is broken.

-  Exclusion List. Flexible control of shared USB devices.

-  VM ware, Virtual PC, VirtualBox compatible.

-  Windows 8/7/2008/Vista compatible.

